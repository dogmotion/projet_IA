python3 /home/evan/Téléchargements/ameliaIA/src/main.py

