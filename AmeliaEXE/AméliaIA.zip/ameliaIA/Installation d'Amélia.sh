sudo apt-get install python python3 xterm

